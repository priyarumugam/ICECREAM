const falvors_list = [
    {
        id: "f001",
        name: "Regular",
        image: "images/regular.jpg"
    },
    {
        id: "f002",
        name: "Gelato",
        image: "images/gelato.jpg"
    },
    {
        id: "f003",
        name: "Sorbet",
        image: "images/sorbet.jpg"
    },
    {
        id: "f004",
        name: "Frozen Yogurt",
        image: "images/yogurt.jpg"
    },
    {
        id: "f005",
        name: "Non-Dairy/Vegan",
        image: "images/vegan.jpg"
    }
]

export default falvors_list;
